<?php

return [
    'bucket' => '',
    'folder' => '/',
    'key' => '',
    'secret' => '',
    'region' => ''
];